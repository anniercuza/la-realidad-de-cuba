Tema inicial de La Realidad de Cuba.

La versión 1 conserva el diseño exacto del prototipo index.html y permite activarlo
como tema de WordPress. La siguiente fase convierte noticias, categorías, galería y
denuncias de demostración en contenido gestionable desde el panel.
