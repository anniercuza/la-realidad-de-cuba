<?php
/**
 * Front page: preserves the supplied visual prototype while running inside WordPress.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$html = file_get_contents( get_template_directory() . '/index.html' );
$bridge = <<<'HTML'
<script>
document.addEventListener('DOMContentLoaded',function(){
  const esc=s=>String(s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
  const card=p=>`<article class="news-card"><div class="p-5"><div class="text-xs font-bold tracking-widest text-red-600 mb-2">NOTICIA</div><h3 class="text-xl font-bold mb-3">${esc(p.title.rendered)}</h3><p class="text-sm opacity-80">${esc(p.excerpt.rendered.replace(/<[^>]+>/g,''))}</p><a class="inline-block mt-4 text-sm font-bold text-red-600" href="${esc(p.link)}">Leer noticia →</a></div></article>`;
  fetch('/wp-json/wp/v2/lrc_news?per_page=6&_embed').then(r=>r.json()).then(items=>{const el=document.getElementById('newsGrid');if(el&&Array.isArray(items)&&items.length)el.innerHTML=items.map(card).join('');}).catch(()=>{});
  fetch('/wp-json/wp/v2/lrc_report?per_page=3').then(r=>r.json()).then(items=>{const el=document.getElementById('homeCitizenFeed');if(el&&Array.isArray(items)&&items.length)el.innerHTML=items.map(p=>`<article class="border-b py-4"><h3 class="font-bold">${esc(p.title.rendered)}</h3><p class="text-sm opacity-80">${esc(p.excerpt.rendered.replace(/<[^>]+>/g,''))}</p></article>`).join('');}).catch(()=>{});
});
</script>
HTML;
$html = str_replace( '</body>', $bridge . '</body>', $html );
echo $html;
