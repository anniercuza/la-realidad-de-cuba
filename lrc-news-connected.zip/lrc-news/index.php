<?php
/**
 * Fallback template for the La Realidad de Cuba theme.
 */
if ( file_exists( __DIR__ . '/front-page.php' ) ) {
    require __DIR__ . '/front-page.php';
} else {
    get_header();
    while ( have_posts() ) {
        the_post();
        the_content();
    }
    get_footer();
}
